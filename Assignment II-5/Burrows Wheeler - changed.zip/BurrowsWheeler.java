import edu.princeton.cs.algs4.BinaryStdIn;
import edu.princeton.cs.algs4.BinaryStdOut;

import java.util.Arrays;

public class BurrowsWheeler {

    // apply Burrows-Wheeler transform,
    // reading from standard input and writing to standard output
    public static void transform() {
        String str = BinaryStdIn.readString();
        CircularSuffixArray csa = new CircularSuffixArray(str);
        // StringBuilder sb = new StringBuilder();
        for (int i = 0; i < csa.length(); i++) {
            if (csa.index(i) == 0) {
                BinaryStdOut.write(i);
                break;
            }
            // sb.append(str.charAt(csa.index(i)));
        }
        // BinaryStdOut.write("\n");
        for (int i = 0; i < csa.length(); i++) {
            BinaryStdOut.write(str.charAt((csa.index(i) + str.length() - 1) % str.length()));
        }
        // BinaryStdOut.write(sb.toString());
        BinaryStdIn.close();
        BinaryStdOut.close();
    }

    private static int[] makeNext(char[] first, String t) {
        int[] next = new int[first.length];
        for (int i = 0; i < first.length; i++) {
            for (int j = 0; j < first.length; j++) {
                if (first[i] == t.charAt(j)) {
                    next[i] = j;
                    break;
                }
            }
        }
        return next;
    }

    // apply Burrows-Wheeler inverse transform,
    // reading from standard input and writing to standard output
    public static void inverseTransform() {
        int nextIdx = BinaryStdIn.readInt();
        // StdOut.println(nextIdx);
        // BinaryStdIn.readChar(); // skip newline character
        String transformed = BinaryStdIn.readString();
        // char[] t = new char[transformed.length()];
        char[] first = new char[transformed.length()];

        for (int i = 0; i < transformed.length(); i++) {
            // t[i] = transformed.charAt(i);
            first[i] = transformed.charAt(i);
        }

        Arrays.sort(first);

        int[] next = makeNext(first, transformed);

        // StringBuilder origString = new StringBuilder();

        int i = 0;

        do {
            BinaryStdOut.write(first[nextIdx]);
            nextIdx = next[nextIdx];
            i++;
        }
        while (i < next.length - 1);

        BinaryStdIn.close();
        BinaryStdOut.close();
        // BinaryStdOut.write(origString.toString());
    }

    // if args[0] is "-", apply Burrows-Wheeler transform
    // if args[0] is "+", apply Burrows-Wheeler inverse transform
    public static void main(String[] args) {
        if (args[0].equals("-")) transform();
        else if (args[0].equals("+")) inverseTransform();
    }

}
