import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;

public class CircularSuffixArrayOld {

    // private String[] origSuffixes;
    // private String[] sortedSuffixes;
    private int[] sortedOrder;
    private MinPQ<String> sorted;

    // circular suffix array of s
    public CircularSuffixArrayOld(String s) {
        if (s == null) throw new IllegalArgumentException();
        // origSuffixes = new String[s.length()];
        // sortedSuffixes = new String[s.length()];
        sortedOrder = new int[s.length()];

        sorted = new MinPQ<>();

        for (int i = 0; i < s.length(); i++) {
            String newString = (s.substring(i)).concat(s.substring(0, i));
            // origSuffixes[i] = newString;
            sorted.insert(newString.concat("-").concat(String.valueOf(i)));
        }

        int counter = 0;
        for (String loopString : sorted) {
            sortedOrder[counter++] = Integer
                    .parseInt(loopString.substring(loopString.lastIndexOf('-') + 1));
        }

        // sorted = null;

        // sortedSuffixes = origSuffixes.clone();
        // Arrays.sort(sortedSuffixes);

        // StdOut.println(Arrays.toString(origSuffixes));
        // StdOut.println("-----");
        // StdOut.println(Arrays.toString(sortedSuffixes));
    }

    // length of s
    public int length() {
        return sortedOrder.length;
    }

    // returns index of ith sorted suffix
    public int index(int i) {
        if (i < 0 || i > sortedOrder.length - 1) throw new IllegalArgumentException();

        return sortedOrder[i];
    }

    // unit testing (required)
    public static void main(String[] args) {
        String str = args[0];
        CircularSuffixArray csa = new CircularSuffixArray(str);
        StdOut.println("For string " + str);
        StdOut.println("Length:  " + csa.length());
        StdOut.println("Index of third sorted in original: " + csa.index(1));
    }

}
